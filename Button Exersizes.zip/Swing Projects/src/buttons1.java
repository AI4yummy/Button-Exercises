import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Math;

public class buttons1 {
    public static void main(String[] args) {
        JPanel panel = new JPanel();
        JPanel buttons = new JPanel();
        JFrame frame = new JFrame("Circle Area Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JTextPane text = new JTextPane();
        JTextField label = new JTextField(20);
        JTextField result = new JTextField(20);
        result.setEditable(false);
        

        JButton clear = new JButton("Clear");
        JButton exit = new JButton("Exit");
        JButton calculate = new JButton("Calculate");
        text.setText("Enter radius");
        
        
        panel.add(text);
        panel.add(label);
        panel.add(result);
        
        buttons.add(clear);
        buttons.add(exit);
        buttons.add(calculate);
        frame.add(panel, BorderLayout.CENTER);
        frame.add(buttons, BorderLayout.SOUTH);
        
        calculate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	double rad = Integer.valueOf(label.getText());
            	double pi = Math.PI;
            	double area = pi * rad * rad;
            	result.setText(String.valueOf(area));	
            }
        });
        
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	result.setText("");
            	label.setText("");
            }
        });
        
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
               System.exit(0);
               //https://stackoverflow.com/questions/2352727/closing-jframe-with-button-click
            }
        });
        frame.setVisible(true);
    }
}