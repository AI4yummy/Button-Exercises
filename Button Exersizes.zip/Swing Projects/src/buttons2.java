import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class buttons2 {
    public static void main(String[] args) {
        JPanel panel = new JPanel();
        JPanel buttons = new JPanel();
        JPanel inputs = new JPanel(); // New panel for input fields and labels
        JFrame frame = new JFrame("Circle Area Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 200);

        JTextPane text = new JTextPane();
        JTextField length = new JTextField(20);
        JTextPane text2 = new JTextPane();
        JTextField width = new JTextField(20);
        JTextField result = new JTextField(20);
        JButton clear = new JButton("Clear");
        JButton exit = new JButton("Exit");
        JButton calculate = new JButton("Calculate");
        text.setText("Enter Length");
        text2.setText("Enter Width");
        text.setEditable(false);
        text2.setEditable(false);
        result.setEditable(false);

        // Set GridLayout for the inputs panel with 3 rows and 2 columns
        inputs.setLayout(new GridLayout(3, 2));

        // Add components to the inputs panel
        inputs.add(text);
        inputs.add(length);
        inputs.add(text2);
        inputs.add(width);
        inputs.add(result);

        // Add inputs panel to the main panel using BorderLayout.CENTER
        panel.add(inputs, BorderLayout.CENTER);

        buttons.add(clear);
        buttons.add(exit);
        buttons.add(calculate);
        
        // Add the main panel to the frame
        frame.add(panel, BorderLayout.CENTER);
        frame.add(buttons, BorderLayout.SOUTH);

        calculate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	double input = Integer.valueOf(length.getText());
            	double inputtwo = Integer.valueOf(width.getText());
            	String combine = length.getText() + width.getText();
            	
            	
            	if (combine.matches("[0-9]+")) {
            	double res;
            	res = input * inputtwo;
            	result.setText(String.valueOf(res));
                } else {
                	 
                    result.setText("One of the inputs contains a letter");
                }
            }
        });

        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                width.setText("");
                length.setText("");
                result.setText("");
            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        frame.setVisible(true);
    }
}
