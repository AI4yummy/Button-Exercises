import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class buttons3 {
    public static void main(String[] args) {
        JPanel panel = new JPanel();
        JPanel buttons = new JPanel();
        JPanel outputPanel = new JPanel();
        JPanel inputs = new JPanel(); // New panel for input fields and labels
        JFrame frame = new JFrame("Circle Area Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 200);

        JLabel text = new JLabel("Enter Age"); // Changed from JTextPane to JLabel
        JTextField name = new JTextField(20);
        JLabel text2 = new JLabel("Enter Name"); // Changed from JTextPane to JLabel
        JTextField age = new JTextField(20);
        JTextField message = new JTextField(20);

        JButton clear = new JButton("Clear");
        JButton exit = new JButton("Exit");
        JButton output = new JButton("Output Message");
        message.setColumns(30);
        message.setEditable(false);
        
        inputs.setLayout(new GridLayout(3, 2));

        // Add components to the inputs panel
        inputs.add(text);
        inputs.add(name);
        inputs.add(text2);
        inputs.add(age);
        
        inputs.add(new JLabel()); // Empty label to align components
        outputPanel.add(message);

        // Add inputs panel to the main panel using BorderLayout.CENTER
        panel.add(inputs, BorderLayout.NORTH);
        outputPanel.add(message);
        buttons.add(clear);
        buttons.add(exit);
        buttons.add(output);

        // Add the main panel to the frame
        frame.add(panel, BorderLayout.NORTH);
        frame.add(outputPanel, BorderLayout.CENTER);
        frame.add(buttons, BorderLayout.SOUTH);

        output.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String str = age.getText();
                int adjust = 0;
                    adjust = Integer.parseInt(name.getText());
                    adjust = adjust - 5;
                    String meesage = "Hello " + str + "! You do not look a day over " + adjust + "!";
                message.setText(meesage);
            } 
        });






        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                name.setText("");
                age.setText("");
                message.setText("");
            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        frame.setVisible(true);
    }
}
